package test2;

class NewOp2 {
    NewOp2(long j, NewOp op, Object obj, long k) {}
}

public class NewOp {
    java.util.Vector listenerList;
    static int i = 0;
    static String s;
    static {
        String m = "test";
        s = m.substring(1);
    }
}
