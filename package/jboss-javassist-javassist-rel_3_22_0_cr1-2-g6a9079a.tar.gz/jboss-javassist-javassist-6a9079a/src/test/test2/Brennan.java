package test2;

public class Brennan {
    private Object format = null;
}
