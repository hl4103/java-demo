package test2;

public class Nested4 {
    private static int value = 6;
}
