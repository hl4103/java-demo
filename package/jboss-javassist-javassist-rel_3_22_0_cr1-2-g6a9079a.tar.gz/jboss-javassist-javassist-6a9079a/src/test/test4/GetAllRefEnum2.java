package test4;

public enum GetAllRefEnum2 { A, B }
