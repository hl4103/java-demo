package test3.sub;

class Visible2 extends test3.Visible {
    public int pub2;
}

public class Visible {
    public int pub;
    protected int pro;
    private int pri;
    int pack;
}
