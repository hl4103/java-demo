package test1;

public class ExprEdit2 {
    int df;
    static int sf;

    public int k1() { df = 3; sf = 7; return df + sf; }
}
