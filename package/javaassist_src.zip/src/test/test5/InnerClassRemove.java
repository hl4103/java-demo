package test5;

public class InnerClassRemove {
    public class A { int a; } 
    class B { int b; } 
    static class C { int c; } 
    public int run() { return 1; }
}
