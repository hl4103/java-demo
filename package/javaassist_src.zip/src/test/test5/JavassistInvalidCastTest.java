package test5;

public class JavassistInvalidCastTest {
    public void inspectReturn(String str) {}
    public void inspectReturn(Object obj) {}
}
