package test5;

public class InvalidCastDollar {
    public static byte[] arrayReturn() {
        return new byte[12];
    }

    public static int intReturn() {
        return 23;
    }
}
