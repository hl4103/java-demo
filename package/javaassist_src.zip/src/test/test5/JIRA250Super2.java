package test5;

public class JIRA250Super2 {
    public JIRA250Bar getBar() { return null; }
}
