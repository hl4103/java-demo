package test4;

public class JIRA93 {
    public void foo() {}
}
