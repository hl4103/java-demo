package test4;

public class length {
    public static int m() { return 7; }
}
